/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sq_exercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import stacksandqueues.*;

/**
 *
 * @author ogm2
 */
public class AgesOfHollywood {
    
    //TODO
    
    public AgesOfHollywood() {
        // TO DO
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public void parseTextFile(String pathname) {
        // TO DO
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
    
}
